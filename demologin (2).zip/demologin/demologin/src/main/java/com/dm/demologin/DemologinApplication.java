package com.dm.demologin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemologinApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemologinApplication.class, args);
	}

}
