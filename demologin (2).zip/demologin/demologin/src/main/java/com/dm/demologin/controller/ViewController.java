package com.dm.demologin.controller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ViewController {

	@RequestMapping("/")
	public String getIndex()
{
	return "index";
}
	
	@RequestMapping("/processForm")
	public String getResult(@RequestParam("name")String name,@RequestParam("pswd")String pswd,Model model)
	{
		if(name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
		return "admin";
		else if(name.equalsIgnoreCase("customer") && pswd.equalsIgnoreCase("pswd"))
			return "customer";
		else
		{
			model.addAttribute("msg","Invalid Credencials!!!");
			return "index";
		}	
	}
	
}
