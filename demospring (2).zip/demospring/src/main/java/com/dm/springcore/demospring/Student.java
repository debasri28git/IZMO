package com.dm.springcore.demospring;
import java.util.*;
import java.util.Arrays;

public class Student {
	
private int id;
private String name;
private Map<String,Integer>marksForSubject;
public Map<String, Integer> getMarksForSubject() {
	return marksForSubject;
}
public void setMarksForSubject(Map<String, Integer> marksForSubject) {
	this.marksForSubject = marksForSubject;
}
private int marks[];
private Set<String> languages;
/*
public List<String> getLanguages() {
	return languages;
}
public void setLanguages(List<String> languages) {
	this.languages = languages;
}
*/
public int[] getMarks() {
	return marks;
}
public Set<String> getLanguages() {
	return languages;
}
public void setLanguages(Set<String> languages) {
	this.languages = languages;
}
public void setMarks(int[] marks) {
	this.marks = marks;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
@Override
public String toString() {
	return "Student [id=" + id + ", name=" + name + ", marksForSubject=" + marksForSubject + ", marks="
			+ Arrays.toString(marks) + ", languages=" + languages + "]";
}


}
