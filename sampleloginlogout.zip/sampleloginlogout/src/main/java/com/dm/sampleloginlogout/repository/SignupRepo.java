package com.dm.sampleloginlogout.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dm.sampleloginlogout.model.Login;

@Repository
public interface SignupRepo extends JpaRepository<Login,String> {

}
