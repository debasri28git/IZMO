package com.dm.sampleloginlogout.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.dm.sampleloginlogout.model.Login;
@Repository
public interface LoginRepo extends JpaRepository<Login,String>{

	@Query("select type from Login l where l.id=?1 and l.password=?2")
	public String getUserByIdAndPassword(String id,String pswd);
	
}
