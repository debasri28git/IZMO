package com.dm.sampleloginlogout.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.sampleloginlogout.model.Login;
import com.dm.sampleloginlogout.service.LoginService;
import com.dm.sampleloginlogout.service.SignupService;
@Controller
public class LoginController {

	@Autowired
	LoginService service;
	
	@Autowired
	SignupService service1;
	
	@RequestMapping("/")
	public String getIndex()
	{
		return "index";
	}
	@RequestMapping("/logout")
	public String logout(HttpSession session)
	{
		session.removeAttribute("name");
		session.invalidate();
		return "index";
	}
	@RequestMapping("/signup")
	public String getSignUp()
	{
		return "signup";
	}
	@RequestMapping(value="/login",method = RequestMethod.POST)
	public String getLogin(@RequestParam("id")String id,@RequestParam("pswd")String pswd,Model model,HttpSession session)
	{
		String type=service.getType(id, pswd);
		if(type.equals("admin"))
		{
			session.setAttribute("name","admin");
			return "admin";
		}
		else if(type.equals("customer"))
		{
			session.setAttribute("name","customer");
			return "customer";
		}
		else
		{
			model.addAttribute("msg","invalid credentials!!");
			return "index";
		}
		
	}
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String getUser(@RequestParam("id")String id,@RequestParam("pswd")String pswd,@RequestParam("type")String type,Model m)
	{
		Login l=new Login();
		l.setId(id);
		l.setPassword(pswd);
		l.setType(type);
		service1.setUser(l);
		m.addAttribute("msg","One User added");
		return "signup";
	}


}
