package com.dm.sampleloginlogout.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.sampleloginlogout.model.Login;
import com.dm.sampleloginlogout.repository.SignupRepo;

@Service
public class SignupService {

	@Autowired
	SignupRepo repo;
	
	public void setUser(Login l)
	{
		repo.save(l);
	}
	
}
