package com.dm.sampleloginlogout;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleloginlogoutApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampleloginlogoutApplication.class, args);
	}

}
