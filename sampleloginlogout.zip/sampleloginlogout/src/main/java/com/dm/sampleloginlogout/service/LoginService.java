package com.dm.sampleloginlogout.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.sampleloginlogout.repository.LoginRepo;

@Service
public class LoginService {

	@Autowired
	LoginRepo repo;
	
	public String getType(String id,String pswd)
	{
		String type=repo.getUserByIdAndPassword(id, pswd);
	  return type;
	}
	
}
