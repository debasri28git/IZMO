package com.dm.sampleloginlogout;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleloginlogoutApplicationTests {

	@Test
	void contextLoads() {
	}

}
