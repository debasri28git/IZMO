package com.dm.googlesecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GooglesecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
