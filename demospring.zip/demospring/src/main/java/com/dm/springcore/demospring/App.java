package com.dm.springcore.demospring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.*;
/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        //System.out.println( "Hello World!" );
        
        ApplicationContext context=new ClassPathXmlApplicationContext("com\\dm\\springcore\\demospring\\conf.xml");
        
        Student s=(Student)context.getBean("stud");
        System.out.println(s);
        
        System.out.println("getting value from xml");
        Student s1=(Student)context.getBean("stud1");
        
        
        Scanner sc=new Scanner(System.in);
        System.out.println("enter id: ");
        int id=sc.nextInt();
        
        System.out.println("enter name: ");
        String nm=sc.next();
        s1.setId(id);
        s1.setName(nm);
        System.out.println("data is:"+s1.getId()+"  "+s1.getName());
        
        System.out.println("getting value from property file");
        
        Student s2=(Student)context.getBean("stud2");
        System.out.println(s2);
    }
}
