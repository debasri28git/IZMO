package com.dm.securitydemogooglelogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecuritydemoGoogleloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
