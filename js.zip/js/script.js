alert("external aler");
console.log("external console.log");