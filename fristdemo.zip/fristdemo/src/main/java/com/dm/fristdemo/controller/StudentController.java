package com.dm.fristdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.fristdemo.model.Student;
import com.dm.fristdemo.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	StudentService service;
	
	@RequestMapping(value = "/add",method = RequestMethod.GET)
	public String getInsert()
	{
		
		return "insert";
	}
	@RequestMapping(value = "/create",method = RequestMethod.POST)
	public String getAdd(@RequestParam("id")String id,@RequestParam("name")String name,Model model)
	{
		Student s=new Student();
		s.setId(Integer.parseInt(id));
		s.setName(name);
		System.out.println(s);
		service.addStudent(s);
		model.addAttribute("msg","One Record Added");
		return "insert";
	}
	
	@RequestMapping(value = "/show",method = RequestMethod.GET)
	public String getShow(Model model)
	{
		List<Student> students=service.showStudents();
		System.out.println(students);
		model.addAttribute("std",students);
		return "display";
	}
	@RequestMapping("/processForm")
	public String getResult(@RequestParam("name")String name,@RequestParam("pswd")String pswd,Model model)
	{
		if(name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
		return "admin";
		else if(name.equalsIgnoreCase("customer") && pswd.equalsIgnoreCase("pswd"))
			return "customer";
		else
		{
			model.addAttribute("msg","Invalid Credencials!!!");
			return "index";
		}	
	}
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String getPAge()
	{
		
		return "index";
	}
}
