package com.dm.DIusingannotation;

import org.springframework.stereotype.Component;

@Component
public class Exam {

	private String result;

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "Exam [result=" + result + "]";
	}
	
}
