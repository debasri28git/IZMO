package com.dm.fristdemo.service;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.dm.fristdemo.model.Student;

@Service
public class StudentService {

	public static List<Student> students=new LinkedList<>();
	
	public void deleteStudent(int id)
	{
		for(int i=0;i<students.size();i++)
		{
			if(students.get(i).getId()==id)
				students.remove(i);
				
		}
	}
	
	public void addStudent(Student s)
	{
				students.add(s);
				
		
	}
	
	public void updateStudent(Student s)
	{
		for(int i=0;i<students.size();i++)
		{
			if(students.get(i).getId()==s.getId())
			{
				students.remove(i);
				students.add(s);
			}
				
		}
	}			
		public List<Student> showStudents()
		{
			return students;
		}
	}

