package com.dm.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dm.dao.StudentDaoImpl;


@WebServlet("/s2")
public class StudentService2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentDaoImpl sm=new StudentDaoImpl();
		String id=request.getParameter("id");
		try {
			int i=sm.delete(Integer.parseInt(id));
			System.out.print(i+" record deleted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("jsp/view.jsp");
	}

}
