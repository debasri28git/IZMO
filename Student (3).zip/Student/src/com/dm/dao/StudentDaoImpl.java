package com.dm.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dm.dao.util.GenerateId;
import com.dm.dao.util.MyConnection;
import com.dm.model.Student;

public class StudentDaoImpl implements StudentDAO {

	@Override
	public int add(Student s) throws SQLException {
 Connection con=MyConnection.getCon();
PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?)");
int id=GenerateId.rand();
  s.setId(id);
 ps.setInt(1, s.getId());
 ps.setString(2, s.getName());
 ps.setString(3, s.getAddress());
 ps.setString(4, s.getMode());
 ps.setString(5, s.getSubjects());
 int i=ps.executeUpdate();	
 return i;
}
  @Override
	public List<Student> read() throws SQLException {
	  Connection con=MyConnection.getCon();
	  Statement st=con.createStatement();//3
	  ResultSet rs=st.executeQuery("select * from student");
	  List<Student> al=new ArrayList<>();
	  while(rs.next())
	  {
		  Student s=new Student();
		  s.setId(rs.getInt("id"));
		  s.setName(rs.getString(2));
		  s.setAddress(rs.getString(3));
		  s.setMode(rs.getString(4));
		  String s1=rs.getString(5);
		  String []s2=s1.split(" ");
		  s.setSubjects(s2);
		  al.add(s);
		  
	  }
	  
		return al;
	}
  @Override
	public void update(Student s) {
		// TODO Auto-generated method stub

	}

	@Override
	public int delete(int id) throws SQLException {
		Connection con=MyConnection.getCon();
		PreparedStatement ps=con.prepareStatement("delete from student where id=?");
		ps.setInt(1,id);
		return ps.executeUpdate();
	}

}
