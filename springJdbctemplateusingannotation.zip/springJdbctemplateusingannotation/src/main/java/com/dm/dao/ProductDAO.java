package com.dm.dao;

import java.util.List;

import com.dm.model.Product;

public interface ProductDAO {
	Product getProductById(int id);

	List<Product> getAllProducts();

	boolean deleteProduct(int id);

	boolean updateProduct(Product p);

	boolean createPerson(Product p);
}
