package com.dm.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.dm.model.Product;
@Component
public class ProductDAOImpl implements ProductDAO{

	
	JdbcTemplate template;
	private final String SELECT_ALL="select * from product";
	private final String SELECT_By_ID="select * from product where pid=?";
	private final String DELETE_By_ID="select from product where pid=?";
	private final String UPDATE_BY_ID="update  product set name=?,cid=?,price=? where pid=?";
	private final String INSERT="insert into product values(?,?,?,?)";
	
	@Autowired
	public ProductDAOImpl(DataSource dataSource) {
		template = new JdbcTemplate(dataSource);
	}
	public Product getProductById(int id) {
		
		return template.queryForObject(SELECT_By_ID,new Object[] {id}, new ProductMapper());
	}

	public List<Product> getAllProducts() {
		
		return template.query(SELECT_ALL, new ProductMapper());
	}

	public boolean deleteProduct(int id) {
		boolean value=template.update(DELETE_By_ID, id)>0;
		return value;
	}

	public boolean updateProduct(Product p) {
		boolean value=template.update(UPDATE_BY_ID, p.getName(),p.getCid(),p.getPrice(),p.getId())>0;
		return value;
	}

	public boolean createPerson(Product p) {
		boolean value=template.update(INSERT, p.getId(),p.getName(),p.getPrice(),p.getCid())>0;
		return value;
	}
	
	

}
