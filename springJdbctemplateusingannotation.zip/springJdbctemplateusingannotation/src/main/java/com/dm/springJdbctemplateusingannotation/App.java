package com.dm.springJdbctemplateusingannotation;




import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.dm.dao.ProductDAO;
import com.dm.model.Product;


/**
 * Hello world!
 *
 */

public class App 
{
	
    public static void main( String[] args )
    {
    	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        System.out.println( "Hello World!" );
        ProductDAO dao=context.getBean(ProductDAO.class);
        System.out.println("product list");
        List<Product> products=dao.getAllProducts();
        for(Product p:products)
        	System.out.println(p);
    }
}
