package com.dm.service;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dm.dao.StudentDaoImpl;
import com.dm.model.Student;

/**
 * Servlet implementation class StudentService4
 */
@WebServlet("/s4")
public class StudentService4 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
        String id=request.getParameter("id");
		String name=request.getParameter("name");
		String add=request.getParameter("add");
		String sub[]=request.getParameterValues("sub");
		String mode=request.getParameter("mode");
		Student stud=new Student();
		stud.setId(Integer.parseInt(id));
		stud.setName(name);
		stud.setAddress(add);
		stud.setMode(mode);
		stud.setSubjects(sub);
		//out.print(stud);
		StudentDaoImpl sm=new StudentDaoImpl();
		try {
			sm.update(stud);
			System.out.print(" record updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("jsp/home.jsp");
	}
	
	}


