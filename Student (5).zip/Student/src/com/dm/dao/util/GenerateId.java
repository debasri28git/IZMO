package com.dm.dao.util;

public class GenerateId {
	public static int rand()
	{
		return (int)(Math.random()*100+1);	
	}
}
