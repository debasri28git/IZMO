package com.dm.dao;

import java.sql.SQLException;
import java.util.List;

import com.dm.model.Student;

public interface StudentDAO {

	int add(Student s) throws SQLException;
	void update(Student s);
	void delete(int id);
	List<Student> read() throws SQLException;
	
	
}
