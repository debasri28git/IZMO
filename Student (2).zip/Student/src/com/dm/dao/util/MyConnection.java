package com.dm.dao.util;

import java.sql.*;
public class MyConnection {

	public static Connection getCon()
	{
		
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/izmo";
		String uid="root";
		String pswd="root";
		
		try{
			Class.forName(driver);
			Connection con=DriverManager.getConnection(url, uid, pswd);
          System.out.println("Connection established");
		  return con;
		
		}catch(Exception e){e.printStackTrace();}
		return null;
		
		

	


	}
}
