package com.dm.service;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dm.dao.StudentDaoImpl;
import com.dm.model.Student;

/**
 * Servlet implementation class StudentService
 */
@WebServlet("/s1")
public class StudentService extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentService() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String name=request.getParameter("sname");
		String add=request.getParameter("add");
		String sub[]=request.getParameterValues("sub");
		String mode=request.getParameter("mode");
		Student stud=new Student();
		stud.setName(name);
		stud.setAddress(add);
		stud.setMode(mode);
		stud.setSubjects(sub);
		out.print(stud);
		StudentDaoImpl sm=new StudentDaoImpl();
		try {
			int i=sm.add(stud);
			System.out.print(i+" record inserted");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("jsp/home.jsp");
			
		
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	
        service(request,response);	
	}

}
