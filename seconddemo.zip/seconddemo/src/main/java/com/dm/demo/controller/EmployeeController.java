package com.dm.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.dm.demo.model.Employee;
import com.dm.demo.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService service;
	
	@RequestMapping(value = "/",method = RequestMethod.GET)
	public String getPAge()
	{
		
		return "index";
	}
	
	@RequestMapping(value = "/add",method = RequestMethod.GET)
	public String getInsert()
	{
		
		return "insert";
	}
	@RequestMapping(value = "/create",method = RequestMethod.POST)
	public String getAdd(@RequestParam("name")String name,@RequestParam("sal")String salary,Model model)
	{
		Employee e=new Employee();
		e.setName(name);
		e.setSalary(Integer.parseInt(salary));
		System.out.println(e);
		service.addEmployee(e);
		model.addAttribute("msg","One Record Added");
		return "insert";
	}
	
	@RequestMapping(value = "/show",method = RequestMethod.GET)
	public String getShow(Model model)
	{
		List<Employee> employees=service.getAllEmployees();
		System.out.println(employees);
		model.addAttribute("emp",employees);
		return "display";
	}
	@RequestMapping("/processForm")
	public String getResult(@RequestParam("name")String name,@RequestParam("pswd")String pswd,Model model)
	{
		if(name.equalsIgnoreCase("admin") && pswd.equalsIgnoreCase("pswd"))
		return "admin";
		else if(name.equalsIgnoreCase("customer") && pswd.equalsIgnoreCase("pswd"))
			return "customer";
		else
		{
			model.addAttribute("msg","Invalid Credencials!!!");
			return "index";
		}	
	}
	
	
}
