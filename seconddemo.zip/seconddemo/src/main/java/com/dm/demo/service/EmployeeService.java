package com.dm.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dm.demo.model.Employee;
import com.dm.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository repository;
	
	public void deleteEmployee(int id)
	{
		repository.deleteById(id);
	}
	
	public void addEmployee(Employee e)
	{
				
				repository.save(e);
		
	}
	
	public void updateEmployee(Employee e)
	{
		repository.save(e);
	}			
		
	public List<Employee> getAllEmployees()
		{
			return repository.findAll();
		}
	}

